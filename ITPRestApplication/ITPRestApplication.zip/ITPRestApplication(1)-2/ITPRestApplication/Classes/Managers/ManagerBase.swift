//
//  ManagerBase.swift
//  ITPRestApplication
//
//  Created by Demo on 1/28/16.
//

import Foundation

class ManagerBase : NSObject {
    

    
    
    
    
}
